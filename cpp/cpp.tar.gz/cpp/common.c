#include "common.h"
int glen = 0;