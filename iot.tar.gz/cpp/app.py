import struct


def crc8_calculate(datatype, length, data):
    crc8 = (datatype >> 0) & 0xFF
    crc8 ^= (datatype >> 8) & 0xFF
    crc8 ^= (length >> 0) & 0xFF
    crc8 ^= (length >> 8) & 0xFF

    for n in range(length):
        crc8 ^= data[n]

    return crc8


# hex 01 10 00 05 /16/ 02 cc cc cc cc
# print('sdfe')
# struct.pack("!2H2B", dst_addr, start_idx) 参数为10进制，2表示两个
# H无符号短数字2byte
# B无符号字符1byte
# Q无符号longlong 8byte
# i整数int 4byte
# L无符号long 4byte 等于I
# ！网络序等于大端 >大端  < 小端 =本地
# 例：
# arr = [255,1,2,3,4,5,6,7]
# print(struct.pack("!2H", *arr[:2]))# 结果 b'\x00\xff\x00\x01'

print((crc8_calculate(0x0110, 5, struct.pack("!5B", *[2, 204, 204, 204, 204]))))
print(0x110)