
#ifndef com_h
#define com_h

// extern int glen;
extern int glen;
#endif